export default function GlossaryPage() {
  return (
    <div className="py-16 md:py-24">
      <div className="container-main max-w-3xl">
        <h1 className="section-title mb-4">Financial Glossary</h1>
        <p className="text-lg text-slate-600 mb-8">
          Clear definitions of banking, finance, FX, FinTech, blockchain, and cybersecurity terms.
        </p>
        <div className="card">
          <p className="text-slate-600">
            Glossary terms will be added progressively. Each term will include a plain-language
            definition, context, and related concepts.
          </p>
        </div>
      </div>
    </div>
  );
}
