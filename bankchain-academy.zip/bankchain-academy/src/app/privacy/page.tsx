export default function PrivacyPage() {
  return (
    <div className="py-16 md:py-24">
      <div className="container-main max-w-3xl">
        <h1 className="section-title mb-6">Privacy Policy</h1>
        <div className="space-y-4 text-slate-600 leading-relaxed">
          <p>
            BankChain Academy is committed to protecting your privacy. We collect only
            the information necessary to operate and improve this educational platform.
          </p>
          <p>
            We do not sell personal data. Any information submitted through contact forms
            is used solely to respond to inquiries.
          </p>
          <p>
            This policy may be updated from time to time. Continued use of the platform
            constitutes acceptance of the current policy.
          </p>
        </div>
      </div>
    </div>
  );
}
