export default function DisclaimerPage() {
  return (
    <div className="py-16 md:py-24">
      <div className="container-main max-w-3xl">
        <h1 className="section-title mb-6">Disclaimer</h1>
        <div className="space-y-4 text-slate-600 leading-relaxed">
          <p>
            BankChain Academy provides educational and informational content only.
            Nothing on this website constitutes financial, investment, legal, tax, or
            professional advice.
          </p>
          <p>
            We do not offer banking services, investment products, securities brokerage,
            cryptocurrency exchange services, lending, or any form of financial intermediation.
          </p>
          <p>
            All content is provided for general educational purposes. Users should conduct
            their own research and consult qualified professionals before making any
            financial decisions.
          </p>
          <p>
            Cryptocurrency and digital asset related content is educational and balanced.
            We clearly communicate risks, volatility, and uncertainty associated with
            these topics.
          </p>
        </div>
      </div>
    </div>
  );
}
