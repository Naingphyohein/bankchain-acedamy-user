export default function ResearchPage() {
  return (
    <div className="py-16 md:py-24">
      <div className="container-main max-w-3xl">
        <h1 className="section-title mb-4">Research Center</h1>
        <p className="text-lg text-slate-600 mb-8">
          Research articles, reports, financial analysis, and case studies.
        </p>
        <div className="card">
          <p className="text-slate-600">
            Research content will be published here as the knowledge base expands.
          </p>
        </div>
      </div>
    </div>
  );
}
