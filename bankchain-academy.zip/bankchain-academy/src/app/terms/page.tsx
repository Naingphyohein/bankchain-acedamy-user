export default function TermsPage() {
  return (
    <div className="py-16 md:py-24">
      <div className="container-main max-w-3xl">
        <h1 className="section-title mb-6">Terms of Use</h1>
        <div className="space-y-4 text-slate-600 leading-relaxed">
          <p>
            By accessing BankChain Academy, you agree to use the platform for educational
            and informational purposes only.
          </p>
          <p>
            Content may not be reproduced, redistributed, or used for commercial purposes
            without prior written permission.
          </p>
          <p>
            We strive for accuracy but do not guarantee that all information is complete,
            current, or error-free. Users are responsible for verifying information before
            relying on it.
          </p>
        </div>
      </div>
    </div>
  );
}
