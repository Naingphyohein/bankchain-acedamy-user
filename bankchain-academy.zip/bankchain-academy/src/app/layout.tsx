import type { Metadata } from "next";
import "./globals.css";
import Providers from "@/components/Providers";

export const metadata: Metadata = {
  title: {
    default: "BankChain Academy | International Financial Education Platform",
    template: "%s | BankChain Academy",
  },
  description:
    "Learn Banking, Finance, FX, FinTech, Blockchain, Web3, Cybersecurity and more. Clear, practical, and responsible financial education for beginners to professionals.",
  keywords: [
    "financial education",
    "banking",
    "fintech",
    "blockchain",
    "cryptocurrency education",
    "FX",
    "digital finance",
    "cybersecurity",
    "fraud awareness",
  ],
  authors: [{ name: "BankChain Academy" }],
  openGraph: {
    type: "website",
    locale: "en_US",
    siteName: "BankChain Academy",
    title: "BankChain Academy | International Financial Education Platform",
    description:
      "Learn. Understand. Explore. Research. Apply. Master modern finance and digital economy knowledge.",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col bg-slate-50">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
