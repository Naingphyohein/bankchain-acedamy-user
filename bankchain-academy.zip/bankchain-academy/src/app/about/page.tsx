"use client";

import { useLocale } from "@/components/Providers";
import { translations } from "@/lib/i18n";

export default function AboutPage() {
  const { locale } = useLocale();
  const t = translations[locale];

  return (
    <div className="py-16 md:py-24">
      <div className="container-main max-w-3xl">
        <h1 className="section-title mb-6">{t.about.title}</h1>
        <p className="text-lg text-slate-600 leading-relaxed mb-8">
          {t.about.mission}
        </p>

        <div className="prose prose-slate max-w-none space-y-6 text-slate-600">
          <p>
            BankChain Academy is designed to provide clear explanations, practical knowledge,
            reliable educational content, research-oriented information, and professional learning
            resources across Banking, Finance, Foreign Exchange, FinTech, Digital Finance,
            Cryptocurrency, Blockchain, Web3, Cybersecurity, and Fraud Awareness.
          </p>
          <p>
            We maintain a clear educational and informational position. Content on this platform
            is not personalized financial, investment, legal, tax, or professional advice.
          </p>
          <p>
            Our core promise: <strong className="text-navy-800">Learn. Understand. Explore. Research. Apply.</strong>
          </p>
        </div>
      </div>
    </div>
  );
}
