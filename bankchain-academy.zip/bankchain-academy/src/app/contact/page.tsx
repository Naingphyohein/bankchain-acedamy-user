export default function ContactPage() {
  return (
    <div className="py-16 md:py-24">
      <div className="container-main max-w-xl">
        <h1 className="section-title mb-4">Contact</h1>
        <p className="text-slate-600 mb-8">
          Have a question or feedback? Reach out to us.
        </p>

        <form className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-navy-800 mb-1.5">Name</label>
            <input
              type="text"
              className="w-full px-4 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500/40 focus:border-teal-500"
              placeholder="Your name"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-navy-800 mb-1.5">Email</label>
            <input
              type="email"
              className="w-full px-4 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500/40 focus:border-teal-500"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-navy-800 mb-1.5">Message</label>
            <textarea
              rows={5}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500/40 focus:border-teal-500"
              placeholder="How can we help?"
            />
          </div>
          <button type="submit" className="btn-primary w-full sm:w-auto">
            Send Message
          </button>
        </form>
      </div>
    </div>
  );
}
