export default function LearningPage() {
  return (
    <div className="py-16 md:py-24">
      <div className="container-main max-w-3xl">
        <h1 className="section-title mb-4">Learning</h1>
        <p className="text-lg text-slate-600 mb-8">
          Structured learning resources for beginners, intermediate learners, and professionals.
        </p>
        <div className="card">
          <p className="text-slate-600">
            Learning pathways, educational materials, and future courses will be published here.
            Content is designed to progress from foundational concepts to advanced topics.
          </p>
        </div>
      </div>
    </div>
  );
}
