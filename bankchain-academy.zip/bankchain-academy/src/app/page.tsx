"use client";

import Link from "next/link";
import { useLocale } from "@/components/Providers";
import { translations, knowledgeAreas } from "@/lib/i18n";

export default function HomePage() {
  const { locale } = useLocale();
  const t = translations[locale];

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-navy-950 via-navy-900 to-navy-800 text-white">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-10 w-72 h-72 bg-teal-500 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-navy-700 rounded-full blur-3xl" />
        </div>

        <div className="container-main relative py-20 md:py-28 lg:py-32">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 text-teal-300 text-sm font-medium mb-6">
              <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />
              International Financial Education Platform
            </div>

            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
              {t.hero.title}
            </h1>

            <p className="mt-6 text-lg md:text-xl text-slate-300 leading-relaxed max-w-2xl">
              {t.hero.subtitle}
            </p>

            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <Link href="/learning" className="btn-teal text-center">
                {t.hero.ctaPrimary}
              </Link>
              <Link
                href="/knowledge"
                className="inline-flex items-center justify-center px-6 py-3 rounded-lg border border-white/30 text-white font-medium hover:bg-white/10 transition-colors"
              >
                {t.hero.ctaSecondary}
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Knowledge Areas */}
      <section className="py-16 md:py-24">
        <div className="container-main">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="section-title">{t.knowledgeAreas.title}</h2>
            <p className="section-subtitle mx-auto">
              {t.knowledgeAreas.subtitle}
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
            {knowledgeAreas.map((area) => (
              <Link
                key={area.id}
                href={`/knowledge#${area.id}`}
                className="card group text-center hover:-translate-y-1 transition-transform duration-200"
              >
                <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-navy-800/10 flex items-center justify-center group-hover:bg-teal-500/20 transition-colors">
                  <span className="text-2xl">
                    {area.icon === "building" && "🏦"}
                    {area.icon === "trending" && "📈"}
                    {area.icon === "globe" && "💱"}
                    {area.icon === "cpu" && "💻"}
                    {area.icon === "smartphone" && "📱"}
                    {area.icon === "bitcoin" && "₿"}
                    {area.icon === "link" && "🔗"}
                    {area.icon === "network" && "🌐"}
                    {area.icon === "shield" && "🛡️"}
                    {area.icon === "alert" && "⚠️"}
                  </span>
                </div>
                <h3 className="font-semibold text-navy-950 text-sm md:text-base">
                  {locale === "en" ? area.en : area.my}
                </h3>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container-main">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="section-title">{t.features.title}</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { title: t.features.clear, desc: t.features.clearDesc },
              { title: t.features.practical, desc: t.features.practicalDesc },
              { title: t.features.responsible, desc: t.features.responsibleDesc },
              { title: t.features.structured, desc: t.features.structuredDesc },
            ].map((item, i) => (
              <div key={i} className="card">
                <div className="w-10 h-10 rounded-lg bg-teal-500/15 flex items-center justify-center mb-4">
                  <span className="text-teal-500 font-bold">{i + 1}</span>
                </div>
                <h3 className="font-semibold text-navy-950 mb-2">{item.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 md:py-20 bg-navy-950 text-white">
        <div className="container-main text-center">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            {t.cta.title}
          </h2>
          <p className="text-slate-300 text-lg max-w-xl mx-auto mb-8">
            {t.cta.subtitle}
          </p>
          <Link href="/knowledge" className="btn-teal">
            {t.cta.button}
          </Link>
        </div>
      </section>
    </>
  );
}
