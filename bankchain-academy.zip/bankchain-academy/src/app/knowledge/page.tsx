"use client";

import Link from "next/link";
import { useLocale } from "@/components/Providers";
import { knowledgeAreas, translations } from "@/lib/i18n";

export default function KnowledgePage() {
  const { locale } = useLocale();
  const t = translations[locale];

  return (
    <div className="py-16 md:py-24">
      <div className="container-main">
        <div className="max-w-2xl mb-12">
          <h1 className="section-title">{t.knowledgeAreas.title}</h1>
          <p className="section-subtitle">{t.knowledgeAreas.subtitle}</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {knowledgeAreas.map((area) => (
            <div key={area.id} id={area.id} className="card">
              <h2 className="font-display font-bold text-xl text-navy-950 mb-2">
                {locale === "en" ? area.en : area.my}
              </h2>
              <p className="text-sm text-slate-600 mb-4">
                Educational resources and explanations related to {area.en}.
              </p>
              <Link
                href={`/knowledge/${area.id}`}
                className="text-sm font-medium text-teal-500 hover:text-teal-400"
              >
                Explore →
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
