import Link from "next/link";
import { translations, type Locale } from "@/lib/i18n";

interface FooterProps {
  locale: Locale;
}

export default function Footer({ locale }: FooterProps) {
  const t = translations[locale].footer;

  return (
    <footer className="bg-navy-950 text-slate-300">
      <div className="container-main py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-steel-500/30 flex items-center justify-center">
                <span className="text-teal-400 font-bold text-sm">BC</span>
              </div>
              <div>
                <span className="font-display font-bold text-white text-lg">
                  BankChain
                </span>
                <span className="block text-xs text-teal-400 font-medium">
                  ACADEMY
                </span>
              </div>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed max-w-xs">
              {t.tagline}
            </p>
          </div>

          {/* Knowledge */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">
              {t.knowledge}
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link href="/knowledge" className="hover:text-teal-400 transition-colors">
                  Banking & Finance
                </Link>
              </li>
              <li>
                <Link href="/knowledge" className="hover:text-teal-400 transition-colors">
                  FinTech & Digital Finance
                </Link>
              </li>
              <li>
                <Link href="/knowledge" className="hover:text-teal-400 transition-colors">
                  Blockchain & Web3
                </Link>
              </li>
              <li>
                <Link href="/knowledge" className="hover:text-teal-400 transition-colors">
                  Cybersecurity
                </Link>
              </li>
            </ul>
          </div>

          {/* Learning */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">
              {t.learning}
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link href="/learning" className="hover:text-teal-400 transition-colors">
                  Learning Resources
                </Link>
              </li>
              <li>
                <Link href="/research" className="hover:text-teal-400 transition-colors">
                  Research Center
                </Link>
              </li>
              <li>
                <Link href="/glossary" className="hover:text-teal-400 transition-colors">
                  Financial Glossary
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">
              {t.legal}
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link href="/about" className="hover:text-teal-400 transition-colors">
                  About
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-teal-400 transition-colors">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/disclaimer" className="hover:text-teal-400 transition-colors">
                  {t.disclaimer}
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-teal-400 transition-colors">
                  {t.privacy}
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-teal-400 transition-colors">
                  {t.terms}
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-navy-800 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-slate-500">
            © {new Date().getFullYear()} BankChain Academy. {t.rights}
          </p>
          <p className="text-xs text-slate-600 max-w-md text-center sm:text-right">
            Educational content only. Not financial, investment, or professional advice.
          </p>
        </div>
      </div>
    </footer>
  );
}
