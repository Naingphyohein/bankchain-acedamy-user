"use client";

import { createContext, useContext, useState, ReactNode } from "react";
import { type Locale } from "@/lib/i18n";
import Header from "./Header";
import Footer from "./Footer";

interface LocaleContextType {
  locale: Locale;
  setLocale: (locale: Locale) => void;
}

const LocaleContext = createContext<LocaleContextType>({
  locale: "en",
  setLocale: () => {},
});

export const useLocale = () => useContext(LocaleContext);

export default function Providers({ children }: { children: ReactNode }) {
  const [locale, setLocale] = useState<Locale>("en");

  return (
    <LocaleContext.Provider value={{ locale, setLocale }}>
      <Header locale={locale} onLocaleChange={setLocale} />
      <main className="flex-1">{children}</main>
      <Footer locale={locale} />
    </LocaleContext.Provider>
  );
}
