"use client";

import Link from "next/link";
import { useState } from "react";
import { translations, type Locale } from "@/lib/i18n";

interface HeaderProps {
  locale: Locale;
  onLocaleChange: (locale: Locale) => void;
}

export default function Header({ locale, onLocaleChange }: HeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const t = translations[locale].nav;

  const navItems = [
    { href: "/", label: t.home },
    { href: "/about", label: t.about },
    { href: "/knowledge", label: t.knowledge },
    { href: "/learning", label: t.learning },
    { href: "/research", label: t.research },
    { href: "/glossary", label: t.glossary },
    { href: "/contact", label: t.contact },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="container-main">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-gradient-to-br from-steel-400 to-steel-600 flex items-center justify-center shadow-soft">
              <div className="w-7 h-7 md:w-8 md:h-8 border-2 border-navy-800 rounded-sm flex items-center justify-center">
                <span className="text-navy-950 font-bold text-sm md:text-base tracking-tighter">
                  BC
                </span>
              </div>
            </div>
            <div className="hidden sm:block">
              <span className="font-display font-bold text-navy-950 text-lg leading-tight">
                BankChain
              </span>
              <span className="block text-xs text-teal-500 font-medium tracking-wide">
                ACADEMY
              </span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="px-3 py-2 text-sm font-medium text-slate-600 hover:text-navy-800 rounded-lg hover:bg-slate-50 transition-colors"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Language + Mobile */}
          <div className="flex items-center gap-3">
            <div className="flex items-center bg-slate-100 rounded-lg p-1">
              <button
                onClick={() => onLocaleChange("en")}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  locale === "en"
                    ? "bg-white text-navy-800 shadow-sm"
                    : "text-slate-500 hover:text-navy-700"
                }`}
              >
                EN
              </button>
              <button
                onClick={() => onLocaleChange("my")}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  locale === "my"
                    ? "bg-white text-navy-800 shadow-sm"
                    : "text-slate-500 hover:text-navy-700"
                }`}
              >
                MY
              </button>
            </div>

            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden p-2 rounded-lg hover:bg-slate-100"
              aria-label="Toggle menu"
            >
              <svg
                className="w-6 h-6 text-navy-800"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                {mobileOpen ? (
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                ) : (
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                )}
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {mobileOpen && (
          <nav className="lg:hidden pb-4 border-t border-slate-100 pt-3">
            <div className="flex flex-col gap-1">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className="px-3 py-2.5 text-sm font-medium text-slate-700 hover:text-navy-800 hover:bg-slate-50 rounded-lg"
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}
