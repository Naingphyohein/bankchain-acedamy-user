export type Locale = "en" | "my";

export const translations = {
  en: {
    nav: {
      home: "Home",
      about: "About",
      knowledge: "Knowledge",
      learning: "Learning",
      research: "Research",
      glossary: "Glossary",
      contact: "Contact",
    },
    hero: {
      title: "Learn. Understand. Explore. Research. Apply.",
      subtitle:
        "An international financial education platform helping you master Banking, Finance, FX, FinTech, Blockchain, and Digital Finance with clarity and confidence.",
      ctaPrimary: "Start Learning",
      ctaSecondary: "Explore Knowledge",
    },
    knowledgeAreas: {
      title: "Knowledge Areas",
      subtitle: "Structured learning paths across modern finance and technology",
    },
    features: {
      title: "Why BankChain Academy",
      clear: "Clear Explanations",
      clearDesc: "Complex concepts explained in practical, accessible language.",
      practical: "Practical Knowledge",
      practicalDesc: "Real-world context and applications you can use.",
      responsible: "Responsible Education",
      responsibleDesc: "Balanced, evidence-based content with clear disclaimers.",
      structured: "Structured Learning",
      structuredDesc: "From beginner to advanced, discover content at your level.",
    },
    cta: {
      title: "Ready to deepen your financial knowledge?",
      subtitle: "Explore our resources, glossary, and learning materials.",
      button: "Browse Knowledge Center",
    },
    footer: {
      tagline: "International Financial Education & Knowledge Platform",
      knowledge: "Knowledge",
      learning: "Learning",
      legal: "Legal",
      disclaimer: "Disclaimer",
      privacy: "Privacy Policy",
      terms: "Terms of Use",
      rights: "All rights reserved.",
    },
    about: {
      title: "About BankChain Academy",
      mission:
        "BankChain Academy is an international financial-education and knowledge platform focused on helping people understand, learn, research, and apply knowledge related to the modern financial and digital economy.",
    },
  },
  my: {
    nav: {
      home: "ပင်မစာမျက်နှာ",
      about: "အကြောင်း",
      knowledge: "အသိပညာ",
      learning: "သင်ယူခြင်း",
      research: "သုတေသန",
      glossary: "ဝေါဟာရ",
      contact: "ဆက်သွယ်ရန်",
    },
    hero: {
      title: "သင်ယူပါ။ နားလည်ပါ။ ရှာဖွေပါ။ သုတေသနလုပ်ပါ။ အသုံးချပါ။",
      subtitle:
        "ဘဏ်လုပ်ငန်း၊ ဘဏ္ဍာရေး၊ FX၊ FinTech၊ Blockchain နှင့် Digital Finance တို့ကို ရှင်းလင်းစွာ နားလည်နိုင်ရန် ကူညီပေးသော နိုင်ငံတကာ ဘဏ္ဍာရေးပညာရေး ပလက်ဖောင်း။",
      ctaPrimary: "စတင်သင်ယူရန်",
      ctaSecondary: "အသိပညာများ ကြည့်ရှုရန်",
    },
    knowledgeAreas: {
      title: "အသိပညာနယ်ပယ်များ",
      subtitle: "ခေတ်မီဘဏ္ဍာရေးနှင့် နည်းပညာဆိုင်ရာ စနစ်တကျ သင်ယူမှုလမ်းကြောင်းများ",
    },
    features: {
      title: "BankChain Academy ကို ဘာကြောင့်ရွေးမလဲ",
      clear: "ရှင်းလင်းသော ရှင်းလင်းချက်များ",
      clearDesc: "ရှုပ်ထွေးသော အယူအဆများကို လက်တွေ့ကျကျ နားလည်ရလွယ်အောင် ရှင်းပြထားသည်။",
      practical: "လက်တွေ့အသိပညာ",
      practicalDesc: "အသုံးချနိုင်သော လက်တွေ့ဆိုင်ရာ အကြောင်းအရာများ။",
      responsible: "တာဝန်သိသော ပညာရေး",
      responsibleDesc: "မျှတပြီး အထောက်အထားအခြေခံသော အကြောင်းအရာများ။",
      structured: "စနစ်တကျ သင်ယူမှု",
      structuredDesc: "အစပြုသူမှ အဆင့်မြင့်အထိ သင့်အဆင့်နှင့် ကိုက်ညီသော အကြောင်းအရာများ။",
    },
    cta: {
      title: "ဘဏ္ဍာရေးအသိပညာကို ပိုမိုနက်ရှိုင်းစွာ လေ့လာရန် အဆင်သင့်ဖြစ်ပါသလား?",
      subtitle: "ကျွန်ုပ်တို့၏ အရင်းအမြစ်များ၊ ဝေါဟာရနှင့် သင်ယူမှုပစ္စည်းများကို လေ့လာပါ။",
      button: "Knowledge Center ကြည့်ရန်",
    },
    footer: {
      tagline: "နိုင်ငံတကာ ဘဏ္ဍာရေးပညာရေးနှင့် အသိပညာပလက်ဖောင်း",
      knowledge: "အသိပညာ",
      learning: "သင်ယူခြင်း",
      legal: "ဥပဒေရေးရာ",
      disclaimer: "ငြင်းဆိုချက်",
      privacy: "ကိုယ်ရေးအချက်အလက် မူဝါဒ",
      terms: "အသုံးပြုမှု စည်းကမ်းများ",
      rights: "မူပိုင်ခွင့်အားလုံး ရယူထားသည်။",
    },
    about: {
      title: "BankChain Academy အကြောင်း",
      mission:
        "BankChain Academy သည် ခေတ်မီဘဏ္ဍာရေးနှင့် ဒစ်ဂျစ်တယ်စီးပွားရေးဆိုင်ရာ အသိပညာများကို နားလည်၊ သင်ယူ၊ သုတေသနလုပ်ပြီး အသုံးချနိုင်ရန် ကူညီပေးသော နိုင်ငံတကာ ဘဏ္ဍာရေးပညာရေး ပလက်ဖောင်းဖြစ်သည်။",
    },
  },
};

export const knowledgeAreas = [
  { id: "banking", en: "Banking", my: "ဘဏ်လုပ်ငန်း", icon: "building" },
  { id: "finance", en: "Finance", my: "ဘဏ္ဍာရေး", icon: "trending" },
  { id: "fx", en: "Foreign Exchange", my: "နိုင်ငံခြားငွေလဲလှယ်မှု", icon: "globe" },
  { id: "fintech", en: "FinTech", my: "FinTech", icon: "cpu" },
  { id: "digital-finance", en: "Digital Finance", my: "ဒစ်ဂျစ်တယ် ဘဏ္ဍာရေး", icon: "smartphone" },
  { id: "crypto", en: "Cryptocurrency", my: "Cryptocurrency", icon: "bitcoin" },
  { id: "blockchain", en: "Blockchain", my: "Blockchain", icon: "link" },
  { id: "web3", en: "Web3", my: "Web3", icon: "network" },
  { id: "cybersecurity", en: "Cybersecurity", my: "ဆိုက်ဘာလုံခြုံရေး", icon: "shield" },
  { id: "fraud", en: "Fraud Awareness", my: "လိမ်လည်မှု အသိပညာ", icon: "alert" },
];
