import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          950: "#0A1628",
          900: "#0F1C2E",
          800: "#1B3A5F",
          700: "#244A73",
          600: "#2E5A87",
        },
        teal: {
          500: "#2A9D8F",
          400: "#4ECDC4",
          300: "#7EDDD6",
        },
        steel: {
          400: "#94A3B8",
          500: "#64748B",
          600: "#475569",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        display: ["Plus Jakarta Sans", "Inter", "system-ui", "sans-serif"],
      },
      boxShadow: {
        soft: "0 4px 20px -2px rgba(10, 22, 40, 0.08)",
        card: "0 8px 30px -4px rgba(10, 22, 40, 0.12)",
      },
    },
  },
  plugins: [],
};

export default config;
